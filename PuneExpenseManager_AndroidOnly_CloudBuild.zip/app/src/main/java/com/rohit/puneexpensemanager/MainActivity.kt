package com.rohit.puneexpensemanager

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class Expense(
    val id: String, val date: String, val category: String,
    val amount: Double, val note: String
)

class MainActivity : Activity() {
    private val green = Color.rgb(22, 107, 67)
    private val pale = Color.rgb(232, 245, 236)
    private val categories = listOf("Outgoing Bus", "Metro", "Breakfast", "Lunch",
        "Incoming Bus", "Dinner", "Additional expenses")
    private val prefs by lazy { getSharedPreferences("pune_expenses", MODE_PRIVATE) }
    private var expenses = mutableListOf<Expense>()
    private var budget = 10000.0
    private lateinit var content: LinearLayout
    private lateinit var totalLabel: TextView
    private lateinit var remainingLabel: TextView
    private lateinit var progress: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        budget = prefs.getString("budget", "10000")?.toDoubleOrNull() ?: 10000.0
        load()
        showHome()
    }

    private fun base(title: String): LinearLayout {
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 28)
            setBackgroundColor(Color.rgb(246, 250, 247))
        }
        scroll.addView(content)
        setContentView(scroll)
        content.addView(text(title, 25f, Color.WHITE, true).apply {
            setBackgroundColor(green); gravity = Gravity.CENTER
            setPadding(12, 22, 12, 22)
        })
        return content
    }

    private fun text(s: String, size: Float = 16f, color: Int = Color.DKGRAY, bold: Boolean = false) =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(8, 8, 8, 8)
        }

    private fun button(label: String, action: () -> Unit) =
        Button(this).apply {
            text = label; isAllCaps = false
            setTextColor(Color.WHITE); setBackgroundColor(green)
            setOnClickListener { action() }
        }

    private fun card(label: String, value: String): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12); setBackgroundColor(Color.WHITE)
            addView(text(label, 13f, green, true))
            addView(text(value, 25f, green, true))
        }

    private fun monthTotal(): Double {
        val month = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
        return expenses.filter { it.date.startsWith(month) }.sumOf { it.amount }
    }

    private fun showHome() {
        base("PUNE EXPENSE MANAGER")
        content.addView(text("Your Daily Money Tracker", 14f, green).apply { gravity = Gravity.CENTER })
        content.addView(card("MONTHLY BUDGET", money(budget)))
        val spent = monthTotal()
        totalLabel = text("TOTAL SPENT  ${money(spent)}", 18f, green, true)
        remainingLabel = text("REMAINING  ${money(budget - spent)}", 18f, green, true)
        content.addView(totalLabel); content.addView(remainingLabel)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = if (budget > 0) ((spent / budget) * 100).toInt().coerceIn(0,100) else 0
        }
        content.addView(progress)
        content.addView(text("${progress.progress}% of monthly budget used", 13f))
        if (spent >= 9000) content.addView(text("Budget alert: you have reached ₹9,000.", 15f, Color.RED, true))
        content.addView(button("+ ADD EXPENSE") { showAdd() })
        content.addView(button("EXPENSE HISTORY") { showHistory() })
        content.addView(button("SET MONTHLY BUDGET") { editBudget() })
        content.addView(button("CATEGORY SUMMARY") { showSummary() })
        content.addView(text("Data is stored offline on this phone.", 12f, Color.GRAY))
    }

    private fun showAdd() {
        base("ADD DAILY EXPENSE")
        val date = EditText(this).apply {
            hint = "Date (YYYY-MM-DD)"
            setText(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()))
        }
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)
        val amount = EditText(this).apply { hint = "Amount in ₹"; inputType = 8194 }
        val note = EditText(this).apply { hint = "Note (optional)" }
        content.addView(text("Date")); content.addView(date)
        content.addView(text("Category")); content.addView(spinner)
        content.addView(text("Amount (₹)")); content.addView(amount)
        content.addView(text("Note")); content.addView(note)
        content.addView(button("SAVE EXPENSE") {
            val d = date.text.toString().trim()
            val a = amount.text.toString().toDoubleOrNull()
            if (!d.matches(Regex("\\d{4}-\\d{2}-\\d{2}")) || a == null || a <= 0) {
                toast("Enter a valid date and amount."); return@button
            }
            expenses.add(Expense(UUID.randomUUID().toString(), d,
                spinner.selectedItem.toString(), a, note.text.toString()))
            save(); toast("Expense saved."); showHome()
        })
        content.addView(button("CANCEL") { showHome() })
    }

    private fun showHistory() {
        base("EXPENSE HISTORY")
        if (expenses.isEmpty()) content.addView(text("No expenses recorded yet."))
        expenses.sortedByDescending { it.date }.forEach { e ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8,10,8,10); setBackgroundColor(Color.WHITE) }
            row.addView(text("${e.date} • ${e.category}", 16f, green, true))
            row.addView(text("${money(e.amount)}${if (e.note.isNotBlank()) " • ${e.note}" else ""}"))
            row.addView(button("DELETE") {
                expenses.removeAll { it.id == e.id }; save(); showHistory()
            })
            content.addView(row)
        }
        content.addView(button("BACK") { showHome() })
    }

    private fun editBudget() {
        base("MONTHLY BUDGET")
        val field = EditText(this).apply { hint = "Budget in ₹"; setText(budget.toInt().toString()); inputType = 8194 }
        content.addView(text("Set your monthly budget (₹)"))
        content.addView(field)
        content.addView(button("SAVE BUDGET") {
            val v = field.text.toString().toDoubleOrNull()
            if (v == null || v <= 0) { toast("Enter a valid budget."); return@button }
            budget = v; prefs.edit().putString("budget", v.toString()).apply()
            showHome()
        })
        content.addView(button("CANCEL") { showHome() })
    }

    private fun showSummary() {
        base("CATEGORY SUMMARY")
        categories.forEach { c ->
            val total = expenses.filter { it.category == c &&
                it.date.startsWith(SimpleDateFormat("yyyy-MM", Locale.US).format(Date())) }.sumOf { it.amount }
            content.addView(text("$c     ${money(total)}", 16f, green, true))
        }
        content.addView(button("BACK") { showHome() })
    }

    private fun money(v: Double) = "₹" + String.format(Locale("en", "IN"), "%,.2f", v)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun save() {
        val arr = JSONArray()
        expenses.forEach { e -> arr.put(JSONObject().apply {
            put("id", e.id); put("date", e.date); put("category", e.category)
            put("amount", e.amount); put("note", e.note)
        }) }
        prefs.edit().putString("expenses", arr.toString()).apply()
    }

    private fun load() {
        val raw = prefs.getString("expenses", "[]") ?: "[]"
        val arr = JSONArray(raw)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            expenses.add(Expense(o.getString("id"), o.getString("date"),
                o.getString("category"), o.getDouble("amount"), o.optString("note")))
        }
    }
}

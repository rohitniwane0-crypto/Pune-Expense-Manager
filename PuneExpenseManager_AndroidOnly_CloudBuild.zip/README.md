# Pune Expense Manager — Android project

This is an Android Studio project for an offline personal expense tracker.

## Features
- Default monthly budget ₹10,000 (editable in the app)
- Seven expense categories
- Daily expense entry with date, amount and optional note
- Monthly total, remaining budget and progress indicator
- Alert at ₹9,000
- Expense history and deletion
- Category-wise monthly summary
- Offline storage using Android SharedPreferences

## Build the APK
1. Open this folder in Android Studio on a computer.
2. Allow Gradle sync and install any requested Android SDK components.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.
5. Transfer it to your Android phone and install it. Android may ask you to allow installation from that source.

The APK is not precompiled in this project package. It must be built using Android Studio.
